import Foundation

public class View: FeedbackView {
    
    // MARK: -
    // MARK: Public functions
    
    public func show(message: String) {
        print(message)
    }
}
