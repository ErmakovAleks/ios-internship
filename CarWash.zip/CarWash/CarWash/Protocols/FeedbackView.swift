import Foundation

public protocol FeedbackView {
    
    // MARK: -
    // MARK: Public functions
    
    func show(message: String)
    
}
