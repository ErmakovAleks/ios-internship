import Foundation

public protocol DirectorContainable {
    var director: Director? { get set }
}
