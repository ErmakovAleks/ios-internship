import Foundation

public protocol Building {
    
    var rooms: [Room] { get set }
    
}
